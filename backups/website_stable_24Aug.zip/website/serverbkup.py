import os
import pandas as pd
from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
import datetime

# Initialize the Flask app
app = Flask(__name__)
CORS(app)

# --- DIRECTORY SETUP ---
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
PLANNED_DIR = os.path.join(BASE_DIR, 'planned_workouts')
TRACKED_DIR = os.path.join(BASE_DIR, 'finished_workouts')

os.makedirs(PLANNED_DIR, exist_ok=True)
os.makedirs(TRACKED_DIR, exist_ok=True)


# --- DATA ANALYSIS FUNCTION ---
def analyze_workout_data():
    """
    Scans all CSVs in the finished_workouts folder, analyzes them,
    and returns a structured dictionary for plotting.
    """
    all_files = [os.path.join(TRACKED_DIR, f) for f in os.listdir(TRACKED_DIR) if f.endswith('.csv')]
    if not all_files:
        return {}

    # Sort files by date, assuming YYYY-MM-DD format in the filename
    all_files.sort()
    
    df_list = []
    for i, file_path in enumerate(all_files):
        try:
            # Extract date and workout name from filename
            filename = os.path.basename(file_path)
            parts = filename.split('_')
            user = parts[0]
            workout_name = parts[1]
            date = parts[2]

            df = pd.read_csv(file_path)
            df['workout_number'] = i + 1
            df['date'] = pd.to_datetime(date)
            df['user'] = user
            df_list.append(df)
        except Exception as e:
            print(f"Could not process file {file_path}: {e}")
            continue

    if not df_list:
        return {}

    full_df = pd.concat(df_list, ignore_index=True)

    # Calculate total volume for each set
    # Fill NaN values in 'Actual Reps' and 'Target Weight (kg)' with 0 before calculation
    full_df['Actual Reps'] = pd.to_numeric(full_df['Actual Reps'], errors='coerce').fillna(0)
    full_df['Target Weight (kg)'] = pd.to_numeric(full_df['Target Weight (kg)'], errors='coerce').fillna(0)
    full_df['volume'] = full_df['Actual Reps'] * full_df['Target Weight (kg)']

    # Group by exercise and workout number to get aggregated stats
    agg_df = full_df.groupby(['Exercise', 'workout_number', 'date', 'user']).agg(
        max_weight=('Target Weight (kg)', 'max'),
        total_volume=('volume', 'sum')
    ).reset_index()

    # Structure the data for the frontend
    analysis_results = {}
    for exercise in agg_df['Exercise'].unique():
        exercise_df = agg_df[agg_df['Exercise'] == exercise].sort_values('workout_number')
        analysis_results[exercise] = {
            'labels': exercise_df['workout_number'].tolist(),
            'dates': exercise_df['date'].dt.strftime('%Y-%m-%d').tolist(),
            'users': exercise_df['user'].tolist(),
            'max_weight': exercise_df['max_weight'].tolist(),
            'total_volume': exercise_df['total_volume'].tolist()
        }
        
    return analysis_results


# --- API ENDPOINTS ---

@app.route('/get_analysis', methods=['GET'])
def get_analysis():
    """Endpoint to trigger the analysis and return results."""
    try:
        results = analyze_workout_data()
        return jsonify({"status": "success", "analysis": results}), 200
    except Exception as e:
        print(f"Error during analysis: {e}")
        return jsonify({"status": "error", "message": "Could not perform analysis."}), 500

@app.route('/list_plans', methods=['GET'])
def list_plans():
    """Scans the planned_workouts directory and returns a list of CSV files."""
    try:
        files = [f for f in os.listdir(PLANNED_DIR) if f.endswith('.csv')]
        files.sort(reverse=True) 
        return jsonify({"status": "success", "plans": files}), 200
    except Exception as e:
        return jsonify({"status": "error", "message": "Could not list workout plans."}), 500

@app.route('/get_plan/<path:filename>')
def get_plan(filename):
    """Serves a specific workout plan file from the planned_workouts directory."""
    try:
        return send_from_directory(PLANNED_DIR, filename, as_attachment=True)
    except FileNotFoundError:
        return jsonify({"status": "error", "message": "File not found."}), 404

@app.route('/save_workout', methods=['POST'])
def save_workout():
    """Saves workout data to the appropriate directory."""
    try:
        data = request.get_json()
        filename, csv_content, workout_type = data.get('filename'), data.get('csv_content'), data.get('type')

        if not all([filename, csv_content, workout_type]):
            return jsonify({"status": "error", "message": "Missing filename, content, or type"}), 400

        save_dir = PLANNED_DIR if workout_type == 'plan' else TRACKED_DIR
        if '..' in filename or '/' in filename:
             return jsonify({"status": "error", "message": "Invalid filename"}), 400

        with open(os.path.join(save_dir, filename), 'w') as f:
            f.write(csv_content)
        return jsonify({"status": "success", "message": f"Workout '{filename}' saved."}), 200
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
