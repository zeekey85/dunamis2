import os
import pandas as pd
from flask import (Flask, request, jsonify, send_from_directory, redirect, 
                   url_for, session, render_template)
from flask_cors import CORS
import datetime
import shutil
import logging
from functools import wraps

app = Flask(__name__, template_folder='web')
CORS(app)

app.secret_key = b'get$trong@dunamis'

logging.basicConfig(level=logging.INFO)

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
WEB_DIR = os.path.join(BASE_DIR, 'web') 
PLANNED_DIR = os.path.join(BASE_DIR, 'planned_workouts')
INPROGRESS_DIR = os.path.join(BASE_DIR, 'inprogress_workouts')
FINISHED_DIR = os.path.join(BASE_DIR, 'finished_workouts')
ARCHIVED_DIR = os.path.join(BASE_DIR, 'archived_plans')
API_DIR = os.path.join(BASE_DIR, 'api')

for directory in [WEB_DIR, PLANNED_DIR, INPROGRESS_DIR, FINISHED_DIR, ARCHIVED_DIR, API_DIR]:
    os.makedirs(directory, exist_ok=True)

def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'logged_in' not in session:
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        if request.form['username'] == 'coach' and request.form['password'] == 'get$trong@dunamis':
            session['logged_in'] = True
            return redirect(url_for('root'))
        else:
            return 'Invalid Credentials. Please try again.'
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.pop('logged_in', None)
    return redirect(url_for('login'))

@app.route('/')
@login_required
def root():
    return redirect(url_for('send_html', path='index.html'))

@app.route('/<path:path>')
@login_required
def send_html(path):
    if path == 'login.html':
        return redirect(url_for('login'))
    return send_from_directory(WEB_DIR, path)

def analyze_workout_data():
    all_files = [os.path.join(FINISHED_DIR, f) for f in os.listdir(FINISHED_DIR) if f.endswith('.csv')]
    if not all_files: return {}
    all_files.sort()
    df_list = []
    for i, file_path in enumerate(all_files):
        try:
            filename = os.path.basename(file_path)
            filename_base = filename.replace('_tracked.csv', '')
            parts = filename_base.split('_')
            if len(parts) < 3: continue
            
            user = parts[0]
            date_str = parts[-1]
            
            try:
                pd.to_datetime(date_str)
            except ValueError:
                app.logger.warning(f"Skipping file with invalid date: {filename}")
                continue

            df = pd.read_csv(file_path)
            
            if 'Actual Reps' not in df.columns: df['Actual Reps'] = 0
            
            if 'Actual Weight (lb)' in df.columns:
                df['Actual Weight'] = pd.to_numeric(df['Actual Weight (lb)'], errors='coerce')
            else:
                df['Actual Weight'] = 0
            
            df['workout_number'] = i + 1
            df['date'] = pd.to_datetime(date_str)
            df['user'] = user
            df_list.append(df)
        except Exception as e:
            app.logger.error(f"Could not process file {file_path}: {e}")
            continue
            
    if not df_list: return {}
    
    full_df = pd.concat(df_list, ignore_index=True)
    full_df['Actual Reps'] = pd.to_numeric(full_df['Actual Reps'], errors='coerce').fillna(0)
    full_df['Actual Weight'] = pd.to_numeric(full_df['Actual Weight'], errors='coerce').fillna(0)
    full_df['volume'] = full_df['Actual Reps'] * full_df['Actual Weight']
    
    agg_df = full_df.groupby(['Exercise', 'workout_number', 'date', 'user']).agg(
        max_weight=('Actual Weight', 'max'),
        total_volume=('volume', 'sum')
    ).reset_index()
    
    analysis_results = {}
    for exercise_name, group in agg_df.groupby('Exercise'):
        group = group.sort_values('date')
        analysis_results[exercise_name] = {
            'labels': group['workout_number'].tolist(),
            'dates': group['date'].dt.strftime('%Y-%m-%d').tolist(),
            'users': group['user'].tolist(),
            'max_weight': group['max_weight'].tolist(),
            'total_volume': group['total_volume'].tolist()
        }
    return analysis_results

@app.route('/api/get_users', methods=['GET'])
@login_required
def get_users():
    try:
        users_path = os.path.join(API_DIR, 'users.csv')
        if not os.path.exists(users_path):
            default_users = pd.DataFrame({'User': ['Zak', 'Kate']})
            default_users.to_csv(users_path, index=False)
        
        df = pd.read_csv(users_path)
        users = sorted(df['User'].unique().tolist())
        return jsonify({"status": "success", "users": users}), 200
    except Exception as e:
        app.logger.error(f"Could not read users file: {e}")
        return jsonify({"status": "error", "message": "Could not read users file."}), 500

@app.route('/api/add_user', methods=['POST'])
@login_required
def add_user():
    try:
        data = request.get_json()
        new_user = data.get('user')

        if not new_user or not isinstance(new_user, str):
            return jsonify({"status": "error", "message": "Invalid user name provided."}), 400

        new_user = new_user.strip().title()
        if not new_user or '..' in new_user or '/' in new_user or ',' in new_user:
             return jsonify({"status": "error", "message": "Invalid characters in user name."}), 400
        
        users_path = os.path.join(API_DIR, 'users.csv')
        
        if not os.path.exists(users_path):
            df = pd.DataFrame(columns=['User'])
        else:
            df = pd.read_csv(users_path)

        if new_user.lower() in df['User'].str.lower().values:
            return jsonify({"status": "error", "message": f"User '{new_user}' already exists."}), 409

        new_row = pd.DataFrame([{'User': new_user}])
        df = pd.concat([df, new_row], ignore_index=True)
        df.to_csv(users_path, index=False)
        
        return jsonify({"status": "success", "message": f"User '{new_user}' added successfully."}), 201
    except Exception as e:
        app.logger.error(f"Error adding user: {e}")
        return jsonify({"status": "error", "message": str(e)}), 500

@app.route('/api/add_exercise', methods=['POST'])
@login_required
def add_exercise():
    try:
        data = request.get_json()
        new_exercise = data.get('exercise')

        if not new_exercise or not isinstance(new_exercise, str):
            return jsonify({"status": "error", "message": "Invalid exercise name provided."}), 400

        new_exercise = new_exercise.strip().title()
        if not new_exercise or '..' in new_exercise or '/' in new_exercise or ',' in new_exercise:
             return jsonify({"status": "error", "message": "Invalid characters in exercise name."}), 400
        
        exercises_path = os.path.join(API_DIR, 'exercises.csv')
        
        if not os.path.exists(exercises_path):
            df = pd.DataFrame(columns=['Exercise'])
        else:
            df = pd.read_csv(exercises_path)

        if new_exercise.lower() in df['Exercise'].str.lower().values:
            return jsonify({"status": "error", "message": f"Exercise '{new_exercise}' already exists."}), 409

        new_row = pd.DataFrame([{'Exercise': new_exercise}])
        df = pd.concat([df, new_row], ignore_index=True)
        df.to_csv(exercises_path, index=False)
        
        return jsonify({"status": "success", "message": f"Exercise '{new_exercise}' added successfully."}), 201
    except Exception as e:
        app.logger.error(f"Error adding exercise: {e}")
        return jsonify({"status": "error", "message": str(e)}), 500

@app.route('/api/get_exercises', methods=['GET'])
@login_required
def get_exercises():
    try:
        exercises_path = os.path.join(API_DIR, 'exercises.csv')
        df = pd.read_csv(exercises_path)
        return jsonify({"status": "success", "exercises": df['Exercise'].tolist()}), 200
    except Exception as e:
        return jsonify({"status": "error", "message": "Could not read exercises file."}), 500

@app.route('/api/list_templates', methods=['GET'])
@login_required
def list_templates():
    try:
        finished_files = [{'filename': f, 'type': 'finished'} for f in os.listdir(FINISHED_DIR) if f.endswith('.csv')]
        archived_files = [{'filename': f, 'type': 'archived'} for f in os.listdir(ARCHIVED_DIR) if f.endswith('.csv')]
        
        all_templates = finished_files + archived_files
        all_templates.sort(key=lambda x: x['filename'], reverse=True)
        return jsonify({"status": "success", "templates": all_templates}), 200
    except Exception as e:
        return jsonify({"status": "error", "message": "Could not list templates."}), 500

@app.route('/api/list_finished_workouts', methods=['GET'])
@login_required
def list_finished_workouts():
    try:
        files = [f for f in os.listdir(FINISHED_DIR) if f.endswith('.csv')]
        files.sort(reverse=True)
        return jsonify({"status": "success", "workouts": files}), 200
    except Exception as e:
        return jsonify({"status": "error", "message": "Could not list finished workouts."}), 500

@app.route('/api/list_workouts_for_tracker', methods=['GET'])
@login_required
def list_workouts_for_tracker():
    try:
        planned_files = [f for f in os.listdir(PLANNED_DIR) if f.endswith('.csv')]
        in_progress_files = [f for f in os.listdir(INPROGRESS_DIR) if f.endswith('_tracked.csv')]
        
        plans_in_progress_base = {f.replace('_tracked.csv', '.csv') for f in in_progress_files}
        active_plans = [p for p in planned_files if p not in plans_in_progress_base]

        active_plans.sort(reverse=True)
        in_progress_files.sort(reverse=True)

        return jsonify({
            "status": "success", 
            "plans": active_plans,
            "tracked": in_progress_files
        }), 200
    except Exception as e:
        return jsonify({"status": "error", "message": "Could not list workouts."}), 500

@app.route('/api/get_workout', methods=['GET'])
@login_required
def get_workout_file():
    filename = request.args.get('filename')
    workout_type = request.args.get('type')
    if not filename or not workout_type:
        return jsonify({"status": "error", "message": "Filename and type are required."}), 400
    
    dir_map = {
        'plan': PLANNED_DIR,
        'tracked': INPROGRESS_DIR,
        'finished': FINISHED_DIR,
        'archived': ARCHIVED_DIR
    }
    directory = dir_map.get(workout_type)

    if not directory:
        return jsonify({"status": "error", "message": "Invalid workout type."}), 400
    
    try:
        return send_from_directory(directory, filename, as_attachment=True)
    except FileNotFoundError:
        return jsonify({"status": "error", "message": "File not found."}), 404

@app.route('/api/get_analysis', methods=['GET'])
@login_required
def get_analysis():
    try:
        results = analyze_workout_data()
        return jsonify({"status": "success", "analysis": results}), 200
    except Exception as e:
        return jsonify({"status": "error", "message": "Could not perform analysis."}), 500

@app.route('/api/save_workout', methods=['POST'])
@login_required
def save_workout():
    try:
        data = request.get_json()
        filename, csv_content, workout_type = data.get('filename'), data.get('csv_content'), data.get('type')
        if not all([filename, csv_content, workout_type]):
            return jsonify({"status": "error", "message": "Missing filename, content, or type"}), 400
        
        if workout_type == 'plan':
            save_dir = PLANNED_DIR
        elif workout_type == 'tracked':
            save_dir = INPROGRESS_DIR
        else:
            return jsonify({"status": "error", "message": "Invalid workout type for saving."}), 400
        
        if '..' in filename or '/' in filename:
             return jsonify({"status": "error", "message": "Invalid filename"}), 400
        
        with open(os.path.join(save_dir, filename), 'w', newline='', encoding='utf-8') as f:
            f.write(csv_content)
        
        return jsonify({"status": "success", "message": f"Workout '{filename}' saved."}), 200
    except Exception as e:
        app.logger.error(f"Error saving workout: {e}")
        return jsonify({"status": "error", "message": str(e)}), 500

@app.route('/api/complete_workout', methods=['POST'])
@login_required
def complete_workout():
    try:
        data = request.get_json()
        tracked_filename = data.get('tracked_filename')
        plan_filename = data.get('plan_filename')

        if not tracked_filename or not plan_filename:
            return jsonify({"status": "error", "message": "Tracked and plan filenames are required."}), 400

        inprogress_path = os.path.join(INPROGRESS_DIR, tracked_filename)
        finished_path = os.path.join(FINISHED_DIR, tracked_filename)
        plan_path = os.path.join(PLANNED_DIR, plan_filename)
        archive_path = os.path.join(ARCHIVED_DIR, plan_filename)

        if os.path.exists(inprogress_path):
            shutil.move(inprogress_path, finished_path)
        
        if os.path.exists(plan_path):
            shutil.move(plan_path, archive_path)
        else:
            app.logger.warning(f"Plan file '{plan_filename}' not found for archiving, but completing workout.")

        return jsonify({"status": "success", "message": "Workout completed and archived."}), 200
    except Exception as e:
        app.logger.error(f"Error completing workout: {e}")
        return jsonify({"status": "error", "message": str(e)}), 500

@app.route('/api/delete_plan', methods=['POST'])
@login_required
def delete_plan():
    try:
        data = request.get_json()
        filename = data.get('filename')

        if not filename or '..' in filename or '/' in filename:
            return jsonify({"status": "error", "message": "Invalid filename provided."}), 400

        file_path = os.path.join(PLANNED_DIR, filename)

        if os.path.exists(file_path):
            os.remove(file_path)
            return jsonify({"status": "success", "message": f"Plan '{filename}' has been deleted."}), 200
        else:
            return jsonify({"status": "error", "message": "Plan not found."}), 404
    except Exception as e:
        app.logger.error(f"Error deleting plan: {e}")
        return jsonify({"status": "error", "message": str(e)}), 500

@app.route('/api/mesocycle_view', methods=['GET'])
@login_required
def mesocycle_view():
    try:
        finished_files = [f for f in os.listdir(FINISHED_DIR) if f.endswith('_tracked.csv')]
        finished_files.sort(reverse=True)

        planned_files = [f for f in os.listdir(PLANNED_DIR) if f.endswith('.csv')]
        
        in_progress_bases = {f.replace('_tracked.csv', '.csv') for f in os.listdir(INPROGRESS_DIR)}
        active_planned_files = [p for p in planned_files if p not in in_progress_bases]
        
        def get_date_from_filename(filename):
            try:
                date_str = filename.split('_')[-1].replace('.csv', '')
                return datetime.datetime.strptime(date_str, '%Y-%m-%d')
            except (IndexError, ValueError):
                return datetime.datetime.max

        active_planned_files.sort(key=get_date_from_filename)

        response_data = {
            "completed": finished_files[:5],
            "planned": active_planned_files[:6]
        }
        return jsonify({"status": "success", "data": response_data}), 200
    except Exception as e:
        app.logger.error(f"Error in mesocycle view: {e}")
        return jsonify({"status": "error", "message": "Could not retrieve mesocycle data."}), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
